from django.contrib import admin

from .models import KirrURL


admin.site.register(KirrURL)

